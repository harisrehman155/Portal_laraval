$(document).ready(function(){new Plyr(".video-player"),new Plyr(".audio-player")});
