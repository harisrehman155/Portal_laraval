!function(t,e,i){"use strict";jQuery("input,select,textarea").not("[type=submit]").jqBootstrapValidation()}(window,document);
