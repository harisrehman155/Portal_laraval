<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('favicon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('favicon/site.webmanifest')); ?> ">
    <link rel="mask-icon" href="<?php echo e(asset('favicon/safari-pinned-tab.svg')); ?>" color="#59595c">
    <meta name="msapplication-TileColor" content="#edf2f7">
    <meta name="theme-color" content="#e8242b">

    <?php echo $__env->yieldContent('meta'); ?>

    <title><?php echo e(Str::snakeToTitle(config('app.name'))); ?></title>
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome/css/font-awesome.min.css')); ?>">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/app.css'))); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.min.css')); ?>" />

    <?php echo $__env->yieldContent('pageStyle'); ?>

    <?php echo $__env->yieldPushContent('myStyle'); ?>

</head>
<body class="bg-gray-200">
    
    <?php echo $__env->yieldContent('afterBodyContent'); ?>

    <div class="container-fluid lg:px-20">
        <?php echo $__env->first(['frontend.components.nav'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="lg:px-x5 min-h-screen">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->first(['frontend.components.footer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    
    <a href="#" id="scroll-to-top">
        <strong>Scroll</strong><br>
        <p>to top</p>
    </a>
    

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    

    <?php echo $__env->yieldPushContent('pageScript'); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('myScript'); ?>

</body>
</html><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/layout/main.blade.php ENDPATH**/ ?>