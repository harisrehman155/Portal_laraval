    
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600">
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/vendors.min.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/ui/prism.min.css'))); ?>">
        
        <?php echo $__env->yieldContent('vendor-style'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/bootstrap.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/bootstrap-extended.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/colors.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/components.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/themes/dark-layout.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/themes/semi-dark-layout.css'))); ?>">

<?php
$configData = Helper::applClasses();
?>
        

        
        
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/core/menu/menu-types/horizontal-menu.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/core/menu/menu-types/vertical-menu.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/core/colors/palette-gradient.css'))); ?>">
<?php /**PATH /home/termzewy/portal.terminatorpunch.com/resources/views/portal/panels/styles.blade.php ENDPATH**/ ?>