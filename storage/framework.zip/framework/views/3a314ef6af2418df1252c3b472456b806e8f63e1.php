<?php $__env->startComponent('mail::message'); ?>

# ORDER ID 0<?php echo e($order->order_id); ?>


----------------------------------------------------------------------------------------------

# Hello!
Your order is ready you can download files. Please click below to download your files.

<?php $__env->startComponent('mail::button', ['url' => $filesUrl]); ?>
    Download Files
<?php echo $__env->renderComponent(); ?>

-----------------------------------------------------------------------------------------------


Thanks,<br>
<?php echo e(str_replace('-' , ' ', config('app.name'))); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH E:\xampp\htdocs\muzzi\resources\views/email/orderCompeleteMail.blade.php ENDPATH**/ ?>