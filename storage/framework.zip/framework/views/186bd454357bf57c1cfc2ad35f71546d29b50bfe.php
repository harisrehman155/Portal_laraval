<?php $__env->startSection('pageStyle'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/contact.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-5">
    <div class="col-lg-6 offset-lg-3 col-md-12">
        <div id="contact-rangecontainer" class="my-5">
            <div id="contact-range">
                <div class="contact-hourmark" style="left:0%;">
                    <div class="contact-hourlabel">12 am</div>
                </div>
                <div class="contact-hourmark" style="left:25%;">
                    <div class="contact-hourlabel">6 am</div>
                </div>
                <div class="contact-hourmark" style="left:50%;">
                    <div class="contact-hourlabel">12 pm</div>
                </div>
                <div class="contact-hourmark" style="left:75%;">
                    <div class="contact-hourlabel">6 pm</div>
                </div>
                <div class="contact-hourmark" style="left:100%;">
                    <div class="contact-hourlabel">12 am</div>
                </div>
                <div id="contact-tick" ></div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 offset-lg-3 col-md-12 pt-5">
        <h2 id="contact-message" class="dinamic-color text-center text-lg leading-6 lg:leading-8 lg:text-xl md:text-xl mb-4">
            We cleared your schedule - go ahead and take that lunch break.
        </h2>

        <p class="text-sm lg:text-lg md:text-lg lg:leading-6 text-center">
            Obsessing about an idea and want to talk about it?<br>
            <strong class="font-bolder">Give us a ring. We love obsessing.</strong>
        </p>

    </div>
</div>
<div class="row mt-3 justify-content-md-center">
    <?php $__currentLoopData = $weatherData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-12 col-md-3 mb-4">
            <div class="weather-container text-center <?php echo e($k ? 'sm:border-t-1' : ''); ?>  py-4">
                <div class="weather-icon icon-position-<?php echo e($item['icon']); ?>"></div>
                <div class="temperature">
                    <h2 class="text-lg"><?php echo e($item['name']); ?></h2>
                    <h1 class="temperature-value display-2 pl-5">
                        <?php echo e($item['temp']); ?>°
                    </h1>
                </div>
                <div class="address">
                    123 Porto Street, New York, USA
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row mt-2 justify-content-md-center bg-gray-300">
    <div class="col-sm-12 col-md-6">
        <div class="subscribe-container py-20">
            <h4 class="text-2xl font-bold text-gray-900"><img class="spark-icon mr-2" src="<?php echo e(asset('images/spark.svg')); ?>" />Stay up to date</h4>
            <h1 class="text-4xl font-bold text-gray-900 mt-3">Subscribe to our newsletter</h1>
            <h3 class="text-xl font-medium mt-3">Be the first to see our latest work.Updates will be rarer then the chance of spotting a pygmy threetoed sloth, so join the fun.</h3>
            <form action="#" class="mt-5 subscribe-form">
                <div class="row">
                    <div class="col-lg-9 col-sm-12">
                        <input type="email" class="form-control" id="email" placeholder="Your Email Address">
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <button type="submit" class="btn btn-theme lg:w-auto md:w-full w-full">Subscribe</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('pageScript'); ?>
    <script src="<?php echo e(asset('js/contact.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('myScript'); ?>
    <script>
        $(document).ready(function(){
            setTimeline(new Date());
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/contact.blade.php ENDPATH**/ ?>