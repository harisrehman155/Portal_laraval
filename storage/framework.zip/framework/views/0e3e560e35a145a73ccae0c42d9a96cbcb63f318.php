<?php $__env->startSection('title', 'Add News'); ?>


<?php $__env->startSection('vendor-style'); ?>     
        <!-- vednor css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/ui/prism.min.css'))); ?>">
         <!-- vednor css files -->
         <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/pickers/pickadate/pickadate.css'))); ?>">
         <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mystyle'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('vendors/css/color-picker/bootstrap-colorpicker.css')); ?>" />	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Description -->
<section id="description">
    <form action="<?php echo e(route('news.store')); ?>" class="w-100" method="post" id="mainForm">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title font-medium-2">Info</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <label for="title-vertical">Title</label>
                                        <input type="text" id="title-vertical" value="<?php echo e(old('title')); ?>" class="form-control <?php echo e($errors->has('title') ? 'border-danger' : ''); ?>" required name="title" placeholder="Title">
                                        <?php if($errors->has('title')): ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($errors->first('title')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="caption-vertical">Caption</label>
                                        <input type="text" id="caption-vertical" value="<?php echo e(old('caption')); ?>" class="form-control <?php echo e($errors->has('caption') ? 'border-danger' : ''); ?>" name="caption" placeholder="Caption">
                                        <?php if($errors->has('caption')): ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($errors->first('caption')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group position-relative">
                                        <label for="caption-vertical">News Date</label>
                                        <input type="text" id="news_date-vertical" value="<?php echo e(old('news_date')); ?>" class="form-control pickadate-months-year <?php echo e($errors->has('news_date') ? 'border-danger' : ''); ?>" name="news_date" placeholder="News Date">
                                        <?php if($errors->has('news_date')): ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($errors->first('news_date')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group mt-2">
                                        <div class="custom-control custom-switch custom-switch-success switch-md custom-control-inline">
                                            <label>Show On Home</label>
                                            <input type="checkbox" class="custom-control-input" name="show_on_home" value="1" id="show_on_home" <?php echo e(old('show_on_home') == '1' ? 'checked' : ''); ?>>
                                            <label class="custom-control-label ml-2" for="show_on_home">
                                                <span class="switch-icon-left">Yes</span>
                                                <span class="switch-icon-right">No</span>
                                            </label>
                                        </div>
                                    </div>
    
                                    <div class="form-group">
                                        <div class="custom-control custom-switch custom-switch-success switch-md  custom-control-inline">
                                            <label>Status</label>
                                            <input type="checkbox" class="custom-control-input" name="status" value="1" id="status" <?php echo e(old('status') == '1' ? 'checked' : ''); ?>>
                                            <label class="custom-control-label ml-2" for="status">
                                                <span class="switch-icon-left ">On</span>
                                                <span class="switch-icon-right">Off</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12">
                                    <div class="form-group">
                                        <label for="seo_url">Select Link <code class="font-weight-bold">(leave blank if you don't want to redirect it to work.)</code></label>
                                        <select class="select2 form-control"  name="seo_url">
                                            <option value="">Select Link</option>
                                            <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="work.<?php echo e($item->seo_url); ?>"><?php echo e($item->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('seo_url')): ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($errors->first('seo_url')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="cover-vertical">Cover Image</label>
                                        <?php echo $__env->renderWhen(true, 'admin.components.imageUpload', ['name' => 'image', 'multiple' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                                    </div>
                                </div>

                                <div class="col mt-2">
                                    <div class="form-group">
                                        <label for="detail">Detail</label>
                                        <textarea height="200px" type="text" id="detail" class="form-control editor <?php echo e($errors->has('detail') ? 'border-danger' : ''); ?>" required name="detail" placeholder="..."><?php echo e(old('detail')); ?></textarea>
                                        <?php if($errors->has('detail')): ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($errors->first('detail')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title font-medium-2">Colors</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="title-vertical">BG Color</label>
                                <div class="input-group color" data-plugin-colorpicker>
                                    <span class="input-group-prepend"><span class="input-group-text input-group-addon"><i></i></span></span>
                                    <input type="text" id="bg_color" name="bg_color" class="form-control" value="<?php echo e(old('bg_color') ? old('bg_color') : '#fff'); ?>">
                                </div>
                                <?php if($errors->has('bg_color')): ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($errors->first('bg_color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="bg_hover_color">BG Hover Color</label>
                                        
                                <div class="input-group color" data-plugin-colorpicker>
                                    <span class="input-group-prepend"><span class="input-group-text input-group-addon"><i></i></span></span>
                                    <input type="text" id="bg_hover_color" name="bg_hover_color" class="form-control" value="<?php echo e(old('bg_hover_color') ? old('bg_hover_color') : '#fff'); ?>">
                                </div>
                                <?php if($errors->has('bg_hover_color')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('bg_hover_color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="line_color">Line Color</label>
                                <div class="input-group color" data-plugin-colorpicker>
                                    <span class="input-group-prepend"><span class="input-group-text input-group-addon"><i></i></span></span>
                                    <input type="text" id="line_color" name="line_color" class="form-control" value="<?php echo e(old('line_color') ? old('line_color') : '#fff'); ?>">
                                </div>
                                <?php if($errors->has('line_color')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('line_color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="line_hover_color">Line Hover Color</label>
                                        
                                <div class="input-group color" data-plugin-colorpicker>
                                    <span class="input-group-prepend"><span class="input-group-text input-group-addon"><i></i></span></span>
                                    <input type="text" id="line_hover_color" name="line_hover_color" class="form-control" value="<?php echo e(old('line_hover_color') ? old('line_hover_color') : '#fff'); ?>">
                                </div>
                                <?php if($errors->has('line_hover_color')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('line_hover_color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="anchor_color">Anchor Color (Link Color)</label>
                                        
                                <div class="input-group color" data-plugin-colorpicker>
                                    <span class="input-group-prepend"><span class="input-group-text input-group-addon"><i></i></span></span>
                                    <input type="text" id="anchor_color" name="anchor_color" class="form-control" value="<?php echo e(old('anchor_color') ? old('anchor_color') : '#fff'); ?>">
                                </div>
                                <?php if($errors->has('anchor_color')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('anchor_color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="anchor_hover_color">Anchor Hover Color (Link Hover Color)</label>
                                        
                                <div class="input-group color" data-plugin-colorpicker>
                                    <span class="input-group-prepend"><span class="input-group-text input-group-addon"><i></i></span></span>
                                    <input type="text" id="anchor_hover_color" name="anchor_hover_color" class="form-control" value="<?php echo e(old('anchor_hover_color') ? old('anchor_hover_color') : '#fff'); ?>">
                                </div>
                                <?php if($errors->has('anchor_hover_color')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('anchor_hover_color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <button class="btn btn-primary float-right waves-effect waves-light" onclick="$('#mainForm').submit()">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</section>
<!--/ Description -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/ui/prism.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/ckeditor/build/ckeditor.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/ckeditor/ckInit.js'))); ?>"></script> 
        
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.date.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/picker.time.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/pickers/pickadate/legacy.js'))); ?>"></script>

        <script src="<?php echo e(asset('vendors/js/color-picker/bootstrap-colorpicker.js')); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('myscript'); ?>
<!-- Page js files -->
<script src="<?php echo e(asset(mix('js/scripts/forms/select/form-select2.js'))); ?>"></script>
<script src="<?php echo e(asset(mix('js/scripts/pickers/dateTime/pick-a-datetime.js'))); ?>"></script>
    <?php echo $__env->make('admin.panels.fileManagerScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.panels.colorPickerInitScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/pages/news/create.blade.php ENDPATH**/ ?>