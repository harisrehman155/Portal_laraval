<?php 
    $sImageIndex = isset($smallIndex) ?  $smallIndex : 0;
    $inputIndex = isset($index) ? $index : ''; 
    $imgData = isset($data) ? is_array($data->image) ? asset($data->image[$sImageIndex]) : $data->image : '';
    $inputVal = isset($data) ? is_array($data->image) ? $data->image[$sImageIndex] : $data->getOriginal('image') : '';
    $inputName = $multiple ? 'thumbnail['.$inputIndex.']'.'['.$name.']' : $name;
    $inputId =  $inputIndex != '' ? $name.'-'.$inputIndex : $name;
?>

<div class="image-upload mb-2 w-full" >    

    <div class="max-width-200 my-1">
        <img src="<?php echo e($imgData != '' ? $imgData : '/images/placeholder.png'); ?>" data-src="/images/placeholder.png"  class="img-thumbnail d-block" />

        <button type="button" onclick="selectImage('<?php echo e($inputId); ?>')" class="btn btn-success w-100 waves-effect waves-light">
            Choose image
        </button>
        
        <input type="hidden" id="<?php echo e($inputId); ?>" value="<?php echo e(old($inputName) ? old($inputName) : $inputVal); ?>" class="form-control" name="<?php echo e($inputName); ?>" placeholder="Cover image">
    </div>                         
    
</div><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/components/imageUpload.blade.php ENDPATH**/ ?>