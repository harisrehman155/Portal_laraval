<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('favicon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('favicon/site.webmanifest')); ?> ">
    <link rel="mask-icon" href="<?php echo e(asset('favicon/safari-pinned-tab.svg')); ?>" color="#59595c">
    <meta name="msapplication-TileColor" content="#edf2f7">
    <meta name="theme-color" content="#e8242b">

    <?php echo $__env->yieldContent('meta'); ?>

    <title><?php echo e(Str::snakeToTitle(config('app.name'))); ?></title>
    
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/jquery.circliful.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/responsive.css')); ?>">
    <link rel="alternate stylesheet" href="<?php echo e(asset('frontend/css/colors/color2.css')); ?>" title="color2" /> <!-- Color2 -->

    <?php echo $__env->yieldPushContent('myStyle'); ?>

</head>
<body class="bg-gray-200">
    
    <?php echo $__env->yieldContent('afterBodyContent'); ?>

    <main>
        <?php echo $__env->first(['frontend.components.nav'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->first(['frontend.components.footer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>
    

    <script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/downCount.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/perfectscrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.circliful.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/custom-scripts.js')); ?>"></script>
    
    

    <?php echo $__env->yieldPushContent('pageScript'); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('myScript'); ?>

</body>
</html><?php /**PATH H:\xampp\htdocs\qurtaba\resources\views/frontend/layout/main.blade.php ENDPATH**/ ?>