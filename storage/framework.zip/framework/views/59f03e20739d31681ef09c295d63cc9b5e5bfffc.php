<header id="header" class="sticky-top bg-gray-200 lg:px-5 md:px-4 py-4 border-bottom">
  <nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="/">
      <img src="<?php echo e(asset('/uploads/images/logo.png')); ?>" alt="Serial Kolor"  class="lg:h-20">
    </a>
    <button class="navbar-toggler border-0 focus:outline-none" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
        <a class="nav-item nav-link <?php echo e((request()->is('/')) ? 'active' : ''); ?>" href="/">Home <span class="sr-only">(current)</span></a>
        <a class="nav-item nav-link <?php echo e((request()->is('works*')) ? 'active' : ''); ?>" href="<?php echo e(route('works')); ?>">Works</a>
        <a class="nav-item nav-link <?php echo e((request()->is('news*')) ? 'active' : ''); ?>" href="<?php echo e(route('news')); ?>">News</a>
        <a class="nav-item nav-link <?php echo e((request()->is('contact')) ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">Contact</a>
      </div>
    </div>
  </nav>
</header>


<?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/components/nav.blade.php ENDPATH**/ ?>