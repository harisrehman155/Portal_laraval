<?php $__env->startSection('content'); ?>
<div class="row grid mt-4">
   

    <div class="grid">
        <div class="grid-sizer col-lg-3"></div>
        <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->renderWhen($works,'frontend.components.work', ['work' => $work], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('pageScript'); ?>
    <script src="<?php echo e(asset('vendors/js/packery/packery.pkgd.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('myScript'); ?>
    <script>
        jQuery(window).on('load', function (e) {
            $('.grid').packery({
                itemSelector: '.grid-item',
                columnWidth: '.grid-sizer',
                percentPosition: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/works.blade.php ENDPATH**/ ?>