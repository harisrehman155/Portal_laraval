<?php $__env->startSection('title', 'File Manager'); ?>

<?php echo $__env->make('ckfinder::setup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('vendor-style'); ?>     
<!-- vednor css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/ui/prism.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Description -->
<section id="description">
    <div class="row">
        <div class="col">
            <div id="ckfinder-widget"></div>
        </div>
    </div>
</section>
<!--/ Description -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/ui/prism.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myscript'); ?>
     <!-- Page js files -->
    <script>
        CKFinder.widget( 'ckfinder-widget', {
            width: '100%',
            height: 700
        } );
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/pages/filemanager.blade.php ENDPATH**/ ?>