

<?php 
    $goto =  collect($work)->has('seo_url') ? route('work.detail', $work->seo_url) : 'javascript:void';
    $sortOrderInput = isset($addInput) ? $addInput : false; 
    $heightClass = '';
    if ($work->size == 'small') {
        $heightClass = 'h-49';
    } 
    if($work->size == 'large') {
        $heightClass = 'lg:h-108 h-49';
    }

    if($work->size == 'medium') {
        $heightClass = 'h-108';
    }
    
?>

<div class="col-xs-12 col-sm-12 col-md-6 col-lg-<?php echo e($work->size != 'large' ? 3 : 6); ?> mb-base grid-item " >
    <a href="<?php echo e($goto); ?>" class="hover:text-gray-500 text-gray-500">
        <?php if($sortOrderInput): ?>
            <input type="hidden" class="sortInput" name="sort[<?php echo e($work->id); ?>]" />
        <?php endif; ?>
        <div id="item-<?php echo e($work->id); ?>" class="grid-item-content work relative <?php echo e($work->size); ?> mb-16">
            <?php if($work->image): ?>
                <img src="<?php echo e(asset($work->image)); ?>" class="img-fluid w-full h-full"/>
            <?php endif; ?>

            <?php if($goto != 'javascript:void'): ?>
                <div class="wrap d-flex flex-column opacity-0 bg-white-900  justify-content-center">
                    <div class="header text-xs lg:text-sm"><?php echo e($work->type == WORK ? 'Work' : 'News'); ?></div>
                    <div class="line"></div>
                    <div class="content p-3 capitalize md:text-3xl text-2xl font-medium">
                        <h3><?php echo $work->title; ?></h3>
                    </div>
                    <div class="line low"></div>
                    <div class="footer text-xs lg:text-sm italic">View project</div>
                </div>
            <?php endif; ?>
        </div>
    </a>
</div>


<?php $__env->startPush('myStyle'); ?>
    <style>
            #item-<?php echo e($work->id); ?> {
                /* color: #FFFFFF; */
                background: <?php echo e($work->bg_color); ?>!important;
            }
    
            #item-<?php echo e($work->id); ?>:hover {
                background: <?php echo e($work->bg_hover_color); ?>!important;
            }
    
            #item-<?php echo e($work->id); ?> h3, #item-<?php echo e($work->id); ?> .header span, #item-<?php echo e($work->id); ?> .footer span {
                color: <?php echo e($work->anchor_color); ?>!important;
            }
    
            #item-<?php echo e($work->id); ?> .arrow-right {
                color: <?php echo e($work->line_color); ?>!important;
            }
    
            #item-<?php echo e($work->id); ?>:hover h3, #item-<?php echo e($work->id); ?>:hover .header span, #item-<?php echo e($work->id); ?>:hover .footer span {
                color: <?php echo e($work->anchor_hover_color); ?>!important;
            }
    
            #item-<?php echo e($work->id); ?> .line {
                background: <?php echo e($work->line_color); ?>!important;
            }
            #item-<?php echo e($work->id); ?>:hover .line , #item-<?php echo e($work->id); ?>:hover .arrow-right {
                background: <?php echo e($work->line_hover_color); ?>!important;                        
            }
    </style>
<?php $__env->stopPush(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/components/work.blade.php ENDPATH**/ ?>