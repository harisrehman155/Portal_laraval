<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('vendor-style'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/tables/datatable/datatables.min.css'))); ?>">
<?php $__env->stopSection(); ?>

  <?php $__env->startSection('content'); ?>
    
    <section id="basic-datatable">
      <div class="row">
          <div class="col-12">
              <div class="card">
                  <div class="card-header">
                      <h4 class="card-title">Your Orders</h4>
                  </div>
                  <div class="card-content">
                      <div class="card-body card-dashboard">
                          <div class="table-responsive">
                              <table class="table zero-configuration">
                                  <thead>
                                      <tr>
                                          <?php $__currentLoopData = $orders->first()->getFillable(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php if($item != 'user_id' && $item != 'status'): ?>
                                                <th><?php echo e(str_replace('_', ' ', ucfirst($item))); ?></th>
                                              <?php endif; ?>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->design_name); ?></td>
                                            <td><?php echo e($item->po_no); ?></td>
                                            <td><?php echo e($item->height); ?></td>
                                            <td><?php echo e($item->weight); ?></td>
                                            <td><?php echo e($item->number_of_colors); ?></td>
                                            <td><?php echo e($item->fabric); ?></td>
                                            <td><?php echo e($item->placement); ?></td>
                                            <td><?php echo e($item->required_format); ?></td>
                                            <td><?php echo unserialize(PROJECT_URGENT_ARRAY)[$item->is_urgent]; ?></td>
                                            <td><?php echo e($item->instructions); ?></td>
                                            <td><?php echo e($item->color_type); ?></td>
                                            
                                            
                                            <td><?php echo unserialize(PROJECT_TYPE_ARRAY)[$item->type]; ?></td>
                                        </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                      
                                  </tbody>
                                  <tfoot>
                                      <tr>
                                        <?php $__currentLoopData = $orders->first()->getFillable(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item != 'user_id' && $item != 'status'): ?>
                                            <th><?php echo e(str_replace('_', ' ', ucfirst($item))); ?></th>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </tr>
                                  </tfoot>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
  <!-- Dashboard Analytics end -->
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('vendor-script'); ?>
  
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/pdfmake.min.js'))); ?>"></script>
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/vfs_fonts.js'))); ?>"></script>
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.min.js'))); ?>"></script>
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js'))); ?>"></script>
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.html5.min.js'))); ?>"></script>
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.print.min.js'))); ?>"></script>
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/buttons.bootstrap.min.js'))); ?>"></script>
          <script src="<?php echo e(asset(mix('vendors/js/tables/datatable/datatables.bootstrap4.min.js'))); ?>"></script>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('myscript'); ?>
          
          <script src="<?php echo e(asset(mix('js/scripts/datatables/datatable.js'))); ?>"></script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('portal/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\muzzi\resources\views/portal/pages/dashboard-analytics.blade.php ENDPATH**/ ?>