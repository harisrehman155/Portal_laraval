<?php echo $__env->make('ckfinder::setup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    function selectImage(inputId) {
        CKFinder.popup( {
            chooseFiles: true,
            width: 800,
            height: 600,
            onInit: function( finder ) {
                finder.on( 'files:choose', function( evt ) {
                    var file = evt.data.files.first();
                    var output = document.getElementById( inputId );
                    var path = file.getUrl().substring(file.getUrl().lastIndexOf("/uploads") + 1);

                    output.value = path;
                    
                    for (let index = 0; index < output.parentNode.childNodes.length; index++) {
                        if(output.parentNode.childNodes[index].nodeName.toLowerCase() == 'img'){
                            $(output.parentNode.childNodes[index]).attr("src", `<?php echo e(env('APP_URL')); ?>/${path}`);
                            break;
                        }   
                    }
                } );
            }
        } );
    }


    function removeImage(inputId,e){
        $(`#${inputId}`).val('');
        $(e).attr('disabled', true);
        var myImage =  $(`#${inputId}`).parent().children('img').attr('src', $(`#${inputId}`).parent().children('img').data('src'));    
    }



    function toggleSelectImage(e,i){
        if($(e).val() == 'small'){
            $(`#div-small-${i}`).show();
        }   else{
            $(`#div-small-${i}`).hide();
        }
    }

</script><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/panels/fileManagerScript.blade.php ENDPATH**/ ?>