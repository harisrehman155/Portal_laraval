<?php if(isset($pageConfigs)): ?>
    <?php echo Helper::updatePageConfig($pageConfigs); ?>

<?php endif; ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?> - Vuexy Vuejs, HTML & Laravel Admin Dashboard Template</title>
        <link rel="shortcut icon" type="image/x-icon" href="images/logo/favicon.ico">

        
        <?php echo $__env->make('admin/panels/styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <link rel="stylesheet" href="<?php echo e(asset(mix('css/main.css'))); ?>">

        <?php echo $__env->yieldContent('mystyle'); ?>
        
        <style>
            div#DataTables_Table_0_processing {
                background: linear-gradient(118deg, #7367f0, rgba(115, 103, 240, 0.7));
                box-shadow: 0 0 8px 1px rgba(115, 103, 240, 0.6);
                color: #fff;
            }
        </style>
    </head>

    
    <?php
        $configData = Helper::applClasses();
    ?>

    
    
<?php echo $__env->make((( $configData["mainLayoutType"] === 'horizontal') ? 'admin/layouts/horizontalLayoutMaster' : 'admin/layouts.verticalLayoutMaster' ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/layouts/contentLayoutMaster.blade.php ENDPATH**/ ?>