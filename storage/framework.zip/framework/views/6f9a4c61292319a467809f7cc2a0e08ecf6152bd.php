<?php echo e($slot); ?>

<?php /**PATH /home/termzewy/portal.terminatorpunch.com/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>