<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\muzzi\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>