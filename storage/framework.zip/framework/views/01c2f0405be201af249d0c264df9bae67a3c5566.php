<?php $__env->startSection('title', 'Edit Work'); ?>


<?php $__env->startSection('vendor-style'); ?>     
<!-- vednor css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/ui/prism.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mystyle'); ?>
        <!-- Page css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/forms/wizard.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Description -->
<section id="description">
    <form method="post"  action="<?php echo e(route('work.update', $work->id)); ?>" id="mainForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="row">
    
            <div class="col-lg-8 offset-lg-2 col-md-12 col-sm-12 ">
            
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title font-medium-2">Info</h4>
                    </div>
                    <div class="card-content">
                        
                        <div class="card-body">
                            <div class="number-tab-steps wizard-circle">
                                <!-- Step 1 -->
                                <h6>Step 1</h6>
                                <fieldset>
                                    <div class="row">
                                        <div class="col-lg-5 col-md-5 col-sm-12">
                                            <div class="form-group">
                                                <label for="title-vertical">Title</label>
                                                <input type="text" value="<?php echo e($work->title); ?>" id="title-vertical" class="form-control <?php echo e($errors->has('title') ? 'border-danger' : ''); ?>"  required name="title" placeholder="Title">
                                                <?php if($errors->has('title')): ?>
                                                    <span class="invalid-feedback d-block" role="alert">
                                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="caption-vertical">Caption</label>
                                                <input type="text" value="<?php echo e($work->caption); ?>" id="caption-vertical" class="form-control <?php echo e($errors->has('caption') ? 'border-danger' : ''); ?>" name="caption" placeholder="Caption">
                                                <?php if($errors->has('caption')): ?>
                                                    <span class="invalid-feedback d-block" role="alert">
                                                        <strong><?php echo e($errors->first('caption')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
            
                                            <div class="form-group">
                                                <label for="year-vertical">Year</label>
                                                <input type="number" value="<?php echo e($work->year); ?>" id="year-vertical" class="form-control" name="year" placeholder="Year">
                                            </div>
            
                                            
            
                                            <div class="form-group">
                                                <label for="year-vertical">Cover Size</label>
                                                <ul class="list-unstyled mb-0">
                                                    
                                                    <li class="d-inline-block mr-2">
                                                        <fieldset>
                                                        <div class="vs-radio-con">
                                                            <input type="radio" name="size" <?php echo e($work->size == 'medium' ? 'checked' :''); ?>  value="medium">
                                                            <span class="vs-radio">
                                                            <span class="vs-radio--border"></span>
                                                            <span class="vs-radio--circle"></span>
                                                            </span>
                                                            <span class="">Medium</span>
                                                        </div>
                                                        </fieldset>
                                                    </li>
                                                    <li class="d-inline-block mr-2">
                                                        <fieldset>
                                                        <div class="vs-radio-con">
                                                            <input type="radio" name="size" <?php echo e($work->size == 'large' ? 'checked' :''); ?> value="large">
                                                            <span class="vs-radio">
                                                            <span class="vs-radio--border"></span>
                                                            <span class="vs-radio--circle"></span>
                                                            </span>
                                                            <span class="">Large</span>
                                                        </div>
                                                        </fieldset>
                                                    </li>
                                                </ul>
                                            </div>

                                            
                                        </div>

                                        <div class="col-lg-7 col-md-5 col-sm-12">
                                            <div class="form-group mt-2">
                                                <div class="custom-control custom-switch custom-switch-success switch-md custom-control-inline">
                                                    <label>Show On Home</label>
                                                    <input type="checkbox" <?php echo e($work->show_on_home ? 'checked' :''); ?> class="custom-control-input" name="show_on_home" value="1" id="show_on_home">
                                                    <label class="custom-control-label ml-2" for="show_on_home">
                                                        <span class="switch-icon-left">Yes</span>
                                                        <span class="switch-icon-right">No</span>
                                                    </label>
                                                </div>
                                            </div>
            
                                            <div class="form-group">
                                                <div class="custom-control custom-switch custom-switch-success switch-md  custom-control-inline">
                                                    <label>Status</label>
                                                    <input type="checkbox" <?php echo e($work->status ? 'checked' :''); ?> class="custom-control-input" name="status" value="1" id="status">
                                                    <label class="custom-control-label ml-2" for="status">
                                                        <span class="switch-icon-left ">On</span>
                                                        <span class="switch-icon-right">Off</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="form-group mt-3">
                                                <label for="cover-vertical">Cover Image</label>
                                                <?php echo $__env->renderWhen(true, 'admin.components.imageUpload', ['name' => 'image', 'multiple' => false , 'data' => $work], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                                            </div>

                                        </div>


                                        <div class="col mt-2">
                                            <div class="form-group">
                                                <label for="detail">Detail</label>
                                                <textarea height="200px" type="text" id="detail" class="form-control editor <?php echo e($errors->has('detail') ? 'border-danger' : ''); ?>" required name="detail" placeholder="detail"><?php echo e($work->detail); ?></textarea>
                                                <?php if($errors->has('detail')): ?>
                                                    <span class="invalid-feedback d-block" role="alert">
                                                        <strong><?php echo e($errors->first('detail')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                       </div>
                                    </div>
                                </fieldset>
                                
                                <!-- Step 2 -->
                                <h6>Step 2</h6>
                                <fieldset>
                                    <div id="tumbnailCard">
                                        <?php $__currentLoopData = $work->thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->renderWhen($item != '','admin.components.workThubmnailClone',['inputIndex' => $k,'data' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
            
                                    <div class="row my-3">
                                        <div class="col">
                                            <button type="button" onclick="addThumnails()" class="btn btn-outline-dark mr-1 mb-1 waves-effect waves-light w-100 border-dashed " data-toggle="modal" data-target="#exampleModalCenter">
                                                <i class="feather icon-plus h3"></i>
                                            </button>
                                        </div>                           
                                    </div>
                                </fieldset>


                                <!-- Step 3 -->
                                <h6>Step 3</h6>
                                <fieldset>
                                    <div id="videoCard">
                                        <?php $__currentLoopData = $work->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->renderWhen($item != '','admin.components.workVideoClone',['inputIndex' => $k,'data' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
            
                                    <div class="row my-3">
                                        <div class="col">
                                            <button type="button" onclick="addVideos()" class="btn btn-outline-dark mr-1 mb-1 waves-effect waves-light w-100 border-dashed " data-toggle="modal" data-target="#exampleModalCenter">
                                                <i class="feather icon-plus h3"></i>
                                            </button>
                                        </div>                           
                                    </div>
                                </fieldset>

                            </div>
                        </div>
                    </div>
                </div>
            
            </div>

            
            

            
        </div>
    </form>
</section>
<!--/ Description -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/ui/prism.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/extensions/jquery.steps.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/forms/validation/jquery.validate.min.js'))); ?>"></script>

        <script src="<?php echo e(asset(mix('vendors/js/ckeditor/build/ckeditor.js'))); ?>"></script>
        
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('myscript'); ?>
    <!-- Page js files -->
    <script src="<?php echo e(asset(mix('js/scripts/forms/wizard-steps.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/ckeditor/ckInit.js'))); ?>"></script>

    <?php echo $__env->make('admin.panels.fileManagerScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        var thumbnailIndex = parseInt(`<?php echo e(count($work->thumbnails->toArray())); ?>`);
        var vedioIndex = parseInt(`<?php echo e(count($work->videos->toArray())); ?>`);
        function addThumnails(){
            
            var clone = `<?php echo $__env->renderWhen(true,'admin.components.workThubmnailClone',['inputIndex' => '`+thumbnailIndex+`'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>`;
            $('#tumbnailCard').append(clone);
            thumbnailIndex++;
        }


        function addVideos(){
            var clone = `<?php echo $__env->renderWhen(true,'admin.components.workVideoClone',['inputIndex' => '`+vedioIndex+`'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>`;
            $('#videoCard').append(clone);
            vedioIndex++;
        }

        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/pages/work/edit.blade.php ENDPATH**/ ?>