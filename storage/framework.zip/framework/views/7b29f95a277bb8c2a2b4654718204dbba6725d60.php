<footer id="footer">
    <div class="row mt-5">
        <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="location border-top py-5">
                <p class="text-xs">
                    © <?php echo e(date('Y')); ?> <?php echo e(Str::snakeToTitle(config('app.name'))); ?>

                </p>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="contact border-top py-5">
                <h3 class="text-md">
                    <a href="#" >Careers</a>
                </h3>
                
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="follow border-top py-5">
                <h3 class="text-md">Follow us</h3>
                <ul class="links pb-5">
                    <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="text-xs twitter"><a href="<?php echo e($item->link); ?>" target="_blank"><i class="fa <?php echo e($item->icon); ?> mr-2"></i><?php echo e(ucwords(explode('-', $item->icon)[1]) ?? ''); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </ul>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="policy border-top py-5">
                <h3 class="text-md">Privacy policy</h3>
                <p class="text-xs">Click <a href="<?php echo e(asset('uploads/files/privacy-policy/Privacy-Policy.pdf')); ?>" class="text-danger hover:text-red-600">here</a> for the Serial Kolor privacy
                    policy.</p>
            </div>
        </div>
    </div>
</footer><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/components/footer.blade.php ENDPATH**/ ?>