<?php $__env->startSection('title', 'Work List'); ?>

<?php $__env->startSection('buttons'); ?>
<div class="row mb-2">
  <div class="col">
      <a href="<?php echo e(route('work.create')); ?>"  type="button" class="btn btn-dark waves-effect waves-light float-right text-white">
        Add<i class="feather icon-plus ml-1 text-lg"></i>
      </a>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('table'); ?>

<table class="table data-thumb-view w-100">
  <thead>
    <tr>
      <th>Id</th>
      <th>Image</th>
      <th>Title</th>
      <th>Size</th>
      <th>Status</th>
      <th class="action">Action</th>
    </tr>
  </thead>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('myscript'); ?>

<script>
  $(function() {

    var table = $('.table').DataTable({
          processing: true,
          serverSide: true,
          searchDelay: 800,
          ajax: '<?php echo route('work.list'); ?>',
          columns: [
            {data: 'id', name: 'id',class:'align-middle'},
            {
                data:'image',name:'image',
                orderable:false,
                searchable:false,
            },
            {data: 'title', name: 'title',class:'align-middle'},
            {data: 'size', name: 'size',class:'align-middle'},
            {data: 'status', name: 'status',class:'align-middle'},                
            {data: 'action', name: 'action', orderable: false, searchable: false,class:'align-middle'}
              
          ]
      });

      var $searchBox = $("#DataTables_Table_0_filter input[type='search']");
      $searchBox.off();

      var searchDebouncedFn = debounce(function() {
        $('.table').DataTable().search($searchBox.val()).draw();
      }, 800);
  
      $searchBox.on("keyup", searchDebouncedFn);

      function debounce(func, wait, immediate) {
          var timeout;
          return function() {
              var context = this, args = arguments;
              var later = function() {
                  timeout = null;
                  if (!immediate) func.apply(context, args);
              };
              var callNow = immediate && !timeout;
              clearTimeout(timeout);
              timeout = setTimeout(later, wait);
              if (callNow) func.apply(context, args);
          };
      };

      

      $('#DataTables_Table_0_filter input').addClass('form-control-md').removeClass('custom-select-sm form-control-sm');
      $('#dataTables_length select').addClass('form-control-md').removeClass('form-control-sm');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/components/datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/pages/work/list.blade.php ENDPATH**/ ?>