[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/termzewy/portal.terminatorpunch.com/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>