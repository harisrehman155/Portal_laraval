<?php
    $videos = isset($data) ? $data : '';
    $title =  $videos != '' ? $videos->title : '';
    $link =  $videos != '' ? $videos->video_link : '';
    $sort =  $videos != '' ? $videos->sort_order : '';
    $size =  $videos != '' ? $videos->size : '';
?>
<div class="row border pt-2 position-relative mt-3 bg-light-grey" id="row-<?php echo e($inputIndex); ?>">

    <button onclick="$(this).parent().remove()" type="button" class="btn-remove btn btn-icon btn-icon rounded-circle btn-danger mr-1 mb-1 waves-effect waves-light">
        <i class="feather icon-x"></i>
    </button>

    <input type="hidden"  class="form-control" name="video[<?php echo e($inputIndex); ?>][type]" value="0" placeholder="sort">

    <div class="col align-self-center">
        
        <div class="form-group ">
            <label for="<?php echo e($inputIndex); ?>-video-title">Vedio Title</label>
        <input type="text" value="<?php echo e($title); ?>" id="<?php echo e($inputIndex); ?>-video-title" class="form-control" name="video[<?php echo e($inputIndex); ?>][title]" placeholder="Title">
        </div>

        <div class="form-group ">
            <label for="<?php echo e($inputIndex); ?>-video-link">Vedio Link <code class="ml-1">Vimeo</code></label>
            <input type="url" value="<?php echo e($link); ?>" id="<?php echo e($inputIndex); ?>-video-link" class="form-control" name="video[<?php echo e($inputIndex); ?>][video_link]" placeholder="Link">
        </div>
        
        <div class="form-group ">
            <label for="<?php echo e($inputIndex); ?>-vedio-sort">Sort Order</label>
            <input type="number" value="<?php echo e($sort); ?>" id="<?php echo e($inputIndex); ?>-vedio-sort" class="form-control" name="video[<?php echo e($inputIndex); ?>][sort_order]" placeholder="sort">
        </div>

        
    </div>
</div><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/components/workVideoClone.blade.php ENDPATH**/ ?>