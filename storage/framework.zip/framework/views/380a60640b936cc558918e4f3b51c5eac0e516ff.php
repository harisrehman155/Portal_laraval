<?php 
    $url = explode('.',$item->seo_url);
    $goto =  collect($item)->has('seo_url') ? route($url[0].'.detail', $url[1]) : 'javascript:void';
?>
<div class="news-item">
    <a href="<?php echo e($goto); ?>">
        <div class="news-content transition-all duration-700" id="item-<?php echo e($item->id); ?>">
            <?php if($item->image): ?>
                <img src="<?php echo e($item->image); ?>" alt="Dummy Image">
            <?php endif; ?>
            <div class="news-detail">
                <div class="n-header transition-all duration-700">
                    <span class="transition-all duration-700">
                        News
                    </span>
                    <div class="n-line transition-all duration-700"></div>
                </div>
                <div class="n-text py-1 transition-all duration-700">
                    <h3 class="text-2xl  md:text-xl font-bold"><?php echo e($item->title); ?></h3>
                </div>
                <div class="n-footer transition-all duration-700">
                    <div class="n-line transition-all duration-700"></div>
                    <span class="transition-all duration-700">
                        <?php echo e(date('d F, Y', strtotime($item->news_date))); ?>

                    </span>
                    
                </div>
            </div>
        </div>
    </a>
</div>


<?php if($item->bg_color): ?>
<?php $__env->startPush('myStyle'); ?>
    <style>
        #item-<?php echo e($item->id); ?> {
            background: <?php echo e($item->bg_color); ?>!important;
        }

        .news-item:hover #item-<?php echo e($item->id); ?> {
            background-color: <?php echo e($item->bg_hover_color); ?>!important;
        }

        .news-item #item-<?php echo e($item->id); ?> .n-text,  .news-item #item-<?php echo e($item->id); ?> .n-header span, .news-item #item-<?php echo e($item->id); ?> .n-footer span {
            color: <?php echo e($item->anchor_color); ?>!important;
        }

        .news-item #item-<?php echo e($item->id); ?> .arrow-right {
            color: <?php echo e($item->line_color); ?>!important;
        }

        .news-item:hover #item-<?php echo e($item->id); ?> .n-text, .news-item:hover #item-<?php echo e($item->id); ?> .n-header span, .news-item:hover #item-<?php echo e($item->id); ?> .n-footer span {
            color: <?php echo e($item->anchor_hover_color); ?>!important;
        }

        .news-item #item-<?php echo e($item->id); ?> .n-line {
            background: <?php echo e($item->line_color); ?>!important;
        }
        .news-item:hover #item-<?php echo e($item->id); ?> .n-line {
            background: <?php echo e($item->line_hover_color); ?>!important;                        
        }
    </style>
<?php $__env->stopPush(); ?>

<?php endif; ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/components/news-page-item.blade.php ENDPATH**/ ?>