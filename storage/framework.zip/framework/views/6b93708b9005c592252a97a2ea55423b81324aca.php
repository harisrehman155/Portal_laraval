<nav class="navbar navbar-expand-lg navbar-light fixed submenu border-bottom pl-0">
    <button class="navbar-toggler border-0 focus:outline-none" type="button" data-toggle="collapse" data-target="#submenu" aria-controls="submenu" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fa fa-filter"></i>
      </button>
    <div class="collapse navbar-collapse" id="submenu">
        <div class="navbar-nav mr-auto">
            <a class="nav-item nav-link cursor-text hover:text-gray-300 <?php echo e((request()->is('/')) ? 'active' : ''); ?>" href="javascript:void(0)" disabled="true">Show</a>
            <a class="nav-item nav-link <?php echo e((request()->is('news')) ? 'active' : ''); ?>" href="<?php echo e(route('news')); ?>">All post</a>
            <a class="nav-item nav-link <?php echo e((request()->is('news/news') || request()->is('news/detail*')) ? 'active' : ''); ?>" href="<?php echo e(route('news', 'news')); ?>">News</a>
            <a class="nav-item nav-link <?php echo e((request()->is('news/twitter')) ? 'active' : ''); ?>" href="<?php echo e(route('news', 'twitter')); ?>">Twitter</a>
            <a class="nav-item nav-link <?php echo e((request()->is('news/instagram')) ? 'active' : ''); ?>" href="<?php echo e(route('news', 'instagram')); ?>">Instagram</a>
        </div>
    </div>
</nav><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/components/submenu.blade.php ENDPATH**/ ?>