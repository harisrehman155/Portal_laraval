<div class="news-item">
        <div class="news-content transition-all duration-700 <?php echo e(strtolower($item->type)); ?>" id="item-<?php echo e($item->id); ?>">
            <?php if($item->image): ?>
                <div class="image-container relative">
                    
                    <?php if($item->post_type == 'video'): ?>
                    <img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->type); ?>">
                        <div class="video-cam-icon"></div>
                        <a href="<?php echo e($item->url); ?>" target="_blank" class="btn-player btn-play z-index-btn-news"></a>
                    <?php else: ?>
                        <a href="<?php echo e($item->url); ?>" target="_blank"><img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->type); ?>"></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="news-detail">
                <div class="n-header transition-all duration-700">
                    <span class="transition-all duration-700">
                        <?php echo e($item->type); ?>

                    </span>
                    <div class="n-line transition-all duration-700"></div>
                </div>
                <div class="n-text py-1 transition-all duration-700">
                    <?php echo $item->title; ?>

                </div>
                <div class="n-footer transition-all duration-700">
                    <div class="n-line transition-all duration-700"></div>
                    <span class="transition-all duration-700">
                        <a href="<?php echo e($item->url); ?>" target="_blank"><p><i class="<?php echo e($item->icon); ?>"></i><?php echo e($item->by); ?></p></a>
                    </span>
                </div>
            </div>
        </div>
</div><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/components/instagram-or-twitter.blade.php ENDPATH**/ ?>