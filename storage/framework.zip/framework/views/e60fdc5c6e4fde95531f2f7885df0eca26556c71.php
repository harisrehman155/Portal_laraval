<?php 
    $thumbnail = isset($data) ? $data : '';
    $size = $thumbnail != '' ? $thumbnail->size : '';
    $sort = $thumbnail != '' ? $thumbnail->sort_order : '';
?>



<div class="row border pt-2 position-relative mt-3 bg-light-grey" id="row-<?php echo e($inputIndex); ?>">

    <button onclick="$(this).parent().remove()" type="button" class="btn-remove btn btn-icon btn-icon rounded-circle btn-danger mr-1 mb-1 waves-effect waves-light"><i class="feather icon-x"></i></button>
    
    <input type="hidden"  class="form-control" name="thumbnail[<?php echo e($inputIndex); ?>][type]" value="1">

    <div class="col-md-7 col-sm-12 align-self-center">
        

        <div class="form-group">
            <label for="<?php echo e($inputIndex); ?>-size">Thumbnail Size</label>
            <ul class="list-unstyled mb-0">
                <li class="d-inline-block mr-2">
                    <fieldset>
                        <div class="vs-radio-con">
                            <input type="radio" name="thumbnail[<?php echo e($inputIndex); ?>][size]" <?php echo e($size == 'small' ? 'checked' : ''); ?> value="small">
                            <span class="vs-radio">
                                <span class="vs-radio--border"></span>
                                <span class="vs-radio--circle"></span>
                            </span>
                            <span class="">Small</span>
                        </div>
                    </fieldset>
                </li>
                <li class="d-inline-block mr-2">
                    <fieldset>
                    <div class="vs-radio-con">
                        <input type="radio" name="thumbnail[<?php echo e($inputIndex); ?>][size]" <?php echo e($size == 'medium' ? 'checked' : ''); ?>  value="medium">
                        <span class="vs-radio">
                        <span class="vs-radio--border"></span>
                        <span class="vs-radio--circle"></span>
                        </span>
                        <span class="">Medium</span>
                    </div>
                    </fieldset>
                </li>
                <li class="d-inline-block mr-2">
                    <fieldset>
                    <div class="vs-radio-con">
                        <input type="radio" name="thumbnail[<?php echo e($inputIndex); ?>][size]" <?php echo e($size == 'large' ? 'checked' : ''); ?>  value="large">
                        <span class="vs-radio">
                        <span class="vs-radio--border"></span>
                        <span class="vs-radio--circle"></span>
                        </span>
                        <span class="">Large</span>
                    </div>
                    </fieldset>
                </li>
            </ul>
        </div>
    </div>

    <?php if($thumbnail != ''): ?>
        <div class="col-md-5 col-sm-12">
            <div class="form-group">
                <label for="<?php echo e($inputIndex); ?>-thumbnail">Image</label>
                    <?php echo $__env->renderWhen(true, 'admin.components.imageUpload', ['name' => 'image', 'multiple' => true,'index' => $inputIndex, 'data' => $thumbnail,'smallIndex' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>  
            </div>
        </div>
    <?php else: ?>
        <div class="col-md-5 col-sm-12">
            <div class="form-group">
                <label for="<?php echo e($inputIndex); ?>-image">Image</label>
                    <?php echo $__env->renderWhen(true, 'admin.components.imageUpload', ['name' => 'image', 'multiple' => true,'index' => $inputIndex], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>  
            </div>
        </div>
    <?php endif; ?>
</div><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/components/workThubmnailClone.blade.php ENDPATH**/ ?>