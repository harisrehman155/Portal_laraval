<?php $__env->startSection('meta'); ?>
    <meta property="fb:app_id" content="2565807603737316"/>
    <meta property="og:title" content="<?php echo e($work->title); ?>"/>
    <meta property="og:url" content="<?php echo e(route('work.detail',$work->seo_url)); ?>"/>
    <meta property="og:type" content="article"/>
    <meta property="og:image" content="<?php echo e($work->image); ?>"/>
    <meta property="og:image:width" content="600"/>
    <meta property="og:image:height" content="400"/>
    <meta property="og:description" content="<?php echo e(strip_tags($work->detail)); ?>"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('afterBodyContent'); ?>
    <div id="onvideoPlay" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" onclick="pause()"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-lg-9 col-md-8 col-sm-12">
        <div class="embed-responsive video-responsive">
            <div data-vimeo-url="<?php echo e($work->details->where('type',0)->sortBy('sort_order')->first()->video_link ?? ''); ?>" class="embed-responsive-item" id="serialKolor">
                <div class="btn-player btn-play" onclick="play(this)"></div>
                <div class="btn-player btn-pause" onclick="pause()"></div>
            </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-4 col-sm-12 ">
        <div class="detail py-3 px-3 bg-gray-300 h-100">
            <div class="content pb-5">
                <?php echo $work->detail; ?>

            </div>

            <div class="content-footer">
                <div class="share-icons">
                    <a class="text-xs md:text-sm" target="_blank" href="https://www.facebook.com/sharer.php?u=<?php echo e(route('work.detail',$work->seo_url)); ?>"><i class="fa fa-facebook"></i></a>
                    <a class="text-xs md:text-sm ml-3" target="_blank" href="https://twitter.com/share?text=<?php echo e(str_replace('|', ' ', $work->title)); ?>...&nbsp;&nbsp;@SerialKolor&amp;url=<?php echo e(route('work.detail',$work->seo_url)); ?>"><i class="fa fa-twitter"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-5 grid">
    <div class="grid">
        <div class="grid-sizer  col-md-6  col-lg-3"></div>
        <?php $__currentLoopData = $work->details->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->renderWhen($w->type,'frontend.components.work', ['work' => $w], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('pageScript'); ?>
<script src="https://player.vimeo.com/api/player.js"></script>
    <script src="<?php echo e(asset('vendors/js/packery/packery.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/workdetail.js')); ?>" ></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/workDetail.blade.php ENDPATH**/ ?>