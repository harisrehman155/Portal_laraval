<?php $__env->startSection('pageStyle'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/news.min.css')); ?>" />
    <style>
        .sticky {
            position: sticky;
            top: 145px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 relative">
        <?php echo $__env->make('frontend.components.submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<div class="row mt-3">
    <div class="col-lg-5 mt-5">
        <div class="bg-white" id="detail">
            <?php if($news->image): ?>
            <div class="new-imge mb-4">
                <img src="<?php echo e($news->image); ?>" class="w-full" />
            </div>
            <?php endif; ?>
            <div class="content news-content relative px-4 pb-5 pt-4">
                <div class="news-header  pb-2 ">
                    <span class="text-xs"><?php echo e(date('d F, Y', strtotime($news->news_date))); ?></span>
                    <div class="line ml-4"></div>
                    <h2 class="text-2xl lg:text-4xl md:text-3xl mt-4"><?php echo e($news->title); ?></h2>
                </div>
                <div class="line low ml-4"></div>
                
                <div class="detail mt-4">
                    <?php echo $news->detail; ?>

                </div>
            </div>
        </div>
        
    </div>
    <div class="col-lg-7 col-md-12">
        <div class="news-grid news-detail-grid mt-5">
            <?php $__currentLoopData = $newsAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($newsAll,'frontend.components.news-page-item', ['item' => $news], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('myScript'); ?>
<script>
    window.onscroll = function() {myFunction()};
    
    var navbar = $('#detail');
    var sticky = navbar.offset.length;
    
    function myFunction() {
      if (window.pageYOffset >= sticky) {
        $('#detail').addClass("sticky");
        
      } else {
        $('#detail').removeClass('sticky');
        console.log(sticky);
      }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/newsDetail.blade.php ENDPATH**/ ?>