<?php
    $configData = Helper::applClasses();
?>
    <body class="horizontal-layout horizontal-menu <?php echo e($configData['blankPageClass']); ?> <?php echo e($configData['bodyClass']); ?> <?php echo e(($configData['theme'] === 'light') ? '' : $configData['theme']); ?> <?php echo e($configData['navbarType']); ?> <?php echo e($configData['sidebarClass']); ?> <?php echo e($configData['footerType']); ?>  footer-light" data-menu="horizontal-menu" data-col="2-columns" data-open="hover">

        
        <?php echo $__env->make('portal.panels.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- BEGIN: Header-->
        
        <?php echo $__env->make('portal.panels.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('portal.panels.horizontalMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- BEGIN: Content-->
        <div class="app-content content">
          <div class="content-overlay"></div>
          <div class="header-navbar-shadow"></div>
            <?php if(!empty($configData['contentLayout'])): ?>
                <div class="content-area-wrapper">
                    <div class="<?php echo e($configData['sidebarPositionClass']); ?>">
                        <div class="sidebar">
                            
                            <?php echo $__env->yieldContent('content-sidebar'); ?>
                        </div>
                    </div>
                    <div class="<?php echo e($configData['contentsidebarClass']); ?>">
                        <div class="content-wrapper">
                            <div class="content-body">
                                
                                <?php echo $__env->yieldContent('content'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="content-wrapper">
                    
                    <?php if($configData['pageHeader'] == true): ?>
                        <?php echo $__env->make('portal.panels.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                    <div class="content-body">

                        
                        <?php echo $__env->yieldContent('content'); ?>

                    </div>
                </div>
            <?php endif; ?>

        </div>
        <!-- End: Content-->

        <div class="sidenav-overlay"></div>
        <div class="drag-target"></div>

        
        <?php echo $__env->make('portal.panels/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('portal.panels/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->yieldContent('myscript'); ?>

    </body>
</html>
<?php /**PATH E:\xampp\htdocs\muzzi\resources\views/portal/layouts/horizontalLayoutMaster.blade.php ENDPATH**/ ?>