<?php $__env->startPush('myStyle'); ?>
    <style>
        header#header {
            display: none;
        }
        .grid-item.is-dragging,
        .grid-item.is-positioning-post-drag {
            background: #C90;
            z-index: 2;
        }

        .packery-drop-placeholder {
            outline: 3px dashed hsla(0, 0%, 0%, 0.5);
            outline-offset: -6px;
            -webkit-transition: -webkit-transform 0.2s;
            transition: transform 0.2s;
        }

        .layoutDesigner {
            position: fixed;
            top: 0px;
            z-index: 9999;
            background: #fff;
            width: 100%;
            padding: 25px 40px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('afterBodyContent'); ?>
<div class="layoutDesigner">
    <button class="btn btn-primary waves-effect waves-light float-right" onclick="$('#formLayout').submit()">
        <i class="fa fa-save mr-3"></i>Save
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Description -->
<form action="<?php echo e(route('work.layout.post', $id)); ?>" method="POST" id="formLayout">
    <?php echo csrf_field(); ?>
    <div class="row mt-20 grid">
        <div class="grid">
            <div class="grid-sizer col-lg-3"></div>
            <?php $__currentLoopData = $thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->renderWhen($w,'frontend.components.work', ['work' => $w, 'addInput' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
</form>

<!--/ Description -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/ui/prism.min.js'))); ?>"></script>  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('myScript'); ?>

<script src="https://unpkg.com/packery@2/dist/packery.pkgd.min.js"></script>
<script src="https://unpkg.com/draggabilly@2/dist/draggabilly.pkgd.js"></script> 

<script src="<?php echo e(asset('js/layout.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/pages/work/layout.blade.php ENDPATH**/ ?>