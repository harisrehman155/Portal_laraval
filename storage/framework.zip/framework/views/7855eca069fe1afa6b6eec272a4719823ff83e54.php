<?php $__env->startSection('title', 'Add Work'); ?>


<?php $__env->startSection('vendor-style'); ?>     
<!-- vednor css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/ui/prism.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mystyle'); ?>
        <!-- Page css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/forms/wizard.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Description -->
<section id="description">
    <div class="row">

        <div class="col-lg-8 offset-lg-2 col-md-12 col-sm-12 ">
            <form action="<?php echo e(route('work.store')); ?>" method="post" id="mainForm">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title font-medium-2">Info</h4>
                    </div>
                    <div class="card-content">
                        
                        <div class="card-body">
                            <div class="number-tab-steps wizard-circle">
                                <!-- Step 1 -->
                                <h6>Info</h6>
                                <fieldset>
                                <div class="row">
                                    <div class="col-lg-5 col-md-5 col-sm-12">
                                            <div class="form-group">
                                                <label for="title-vertical">Title</label>
                                                <input type="text" id="title-vertical" value="<?php echo e(old('title')); ?>" class="form-control <?php echo e($errors->has('title') ? 'border-danger' : ''); ?>" required name="title" placeholder="Title">
                                                <?php if($errors->has('title')): ?>
                                                    <span class="invalid-feedback d-block" role="alert">
                                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
        
                                            <div class="form-group">
                                                <label for="caption-vertical">Caption</label>
                                                <input type="text" id="caption-vertical" value="<?php echo e(old('caption')); ?>" class="form-control <?php echo e($errors->has('caption') ? 'border-danger' : ''); ?>" name="caption" placeholder="Caption">
                                                <?php if($errors->has('caption')): ?>
                                                    <span class="invalid-feedback d-block" role="alert">
                                                        <strong><?php echo e($errors->first('caption')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
            
                                            <div class="form-group">
                                                <label for="year-vertical">Year</label>
                                                <input type="number" id="year-vertical" value="<?php echo e(old('year')); ?>" class="form-control" name="year" placeholder="Year">
                                            </div>
            
                                            <div class="form-group">
                                                <label for="year-vertical">Cover Size</label>
                                                <ul class="list-unstyled mb-0">
                                                    <li class="d-inline-block mr-2">
                                                        <fieldset>
                                                        <div class="vs-radio-con">
                                                            <input type="radio" name="size"  value="medium" <?php echo e(old('size') == 'medium' ? 'checked' : ''); ?>>
                                                            <span class="vs-radio">
                                                            <span class="vs-radio--border"></span>
                                                            <span class="vs-radio--circle"></span>
                                                            </span>
                                                            <span class="">Medium</span>
                                                        </div>
                                                        </fieldset>
                                                    </li>
                                                    <li class="d-inline-block mr-2">
                                                        <fieldset>
                                                        <div class="vs-radio-con">
                                                            <input type="radio" name="size"  value="large" <?php echo e(old('size') == 'large' ? 'checked' : ''); ?>>
                                                            <span class="vs-radio">
                                                            <span class="vs-radio--border"></span>
                                                            <span class="vs-radio--circle"></span>
                                                            </span>
                                                            <span class="">Large</span>
                                                        </div>
                                                        </fieldset>
                                                    </li>
                                                </ul>
                                            </div>
        
                                            
                                    </div>

                                    <div class="col-lg-7 col-md-5 col-sm-12">
                                            <div class="form-group mt-2">
                                                <div class="custom-control custom-switch custom-switch-success switch-md custom-control-inline">
                                                    <label>Show On Home</label>
                                                    <input type="checkbox" class="custom-control-input" name="show_on_home" value="1" id="show_on_home" <?php echo e(old('show_on_home') == '1' ? 'checked' : ''); ?>>
                                                    <label class="custom-control-label ml-2" for="show_on_home">
                                                        <span class="switch-icon-left">Yes</span>
                                                        <span class="switch-icon-right">No</span>
                                                    </label>
                                                </div>
                                            </div>
            
                                            <div class="form-group">
                                                <div class="custom-control custom-switch custom-switch-success switch-md  custom-control-inline">
                                                    <label>Status</label>
                                                    <input type="checkbox" class="custom-control-input" name="status" value="1" id="status" <?php echo e(old('status') == '1' ? 'checked' : ''); ?>>
                                                    <label class="custom-control-label ml-2" for="status">
                                                        <span class="switch-icon-left ">On</span>
                                                        <span class="switch-icon-right">Off</span>
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="form-group mt-1">
                                                <label for="cover-vertical">Cover Image</label>
                                                <?php echo $__env->renderWhen(true, 'admin.components.imageUpload', ['name' => 'image', 'multiple' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                                            </div>
                                            
                                    </div>

                                    <div class="col mt-2">
                                        <div class="form-group">
                                            <label for="detail">Detail</label>
                                            <textarea height="200px" type="text" id="detail" class="form-control editor <?php echo e($errors->has('detail') ? 'border-danger' : ''); ?>" required name="detail" placeholder="..."><?php echo e(old('detail')); ?></textarea>
                                            <?php if($errors->has('detail')): ?>
                                                <span class="invalid-feedback d-block" role="alert">
                                                    <strong><?php echo e($errors->first('detail')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                </fieldset>
                                
                                <!-- Step 2 -->
                                <h6>Thumbnails</h6>
                                <fieldset>
                                    

                                    
                                    <div id="tumbnailCard">

                                    </div>
            
                                    <div class="row my-3">
                                        <div class="col">
                                            
                                            <button type="button" onclick="addThumnails()" class="btn btn-outline-dark mr-1 mb-1 waves-effect waves-light w-100 border-dashed " data-toggle="modal" data-target="#exampleModalCenter">
                                                <i class="feather icon-plus h3"></i>
                                            </button>
                                        </div>                           
                                    </div>
                                </fieldset>


                                <!-- Step 3 -->
                                <h6>Videos</h6>
                                <fieldset>
                                    <div id="videoCard">

                                    </div>
            
                                    <div class="row my-3">
                                        <div class="col">
                                            <button type="button" onclick="addVideos()" class="btn btn-outline-dark mr-1 mb-1 waves-effect waves-light w-100 border-dashed " data-toggle="modal" data-target="#exampleModalCenter">
                                                <i class="feather icon-plus h3"></i>
                                            </button>
                                        </div>                           
                                    </div>
                                </fieldset>

                            </div>
                        </div>
                    </div>
                </div>
                
            </form>
            
        </div>
        
    </div>
</section>
<!--/ Description -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/ui/prism.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/extensions/jquery.steps.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/forms/validation/jquery.validate.min.js'))); ?>"></script>

        <script src="<?php echo e(asset(mix('vendors/js/ckeditor/build/ckeditor.js'))); ?>"></script>
        

        <script src="https://unpkg.com/packery@2/dist/packery.pkgd.min.js"></script>
        <script src="https://unpkg.com/draggabilly@2/dist/draggabilly.pkgd.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('myscript'); ?>
     <!-- Page js files -->
     <script src="<?php echo e(asset(mix('js/scripts/forms/wizard-steps.js'))); ?>"></script>
     <script src="<?php echo e(asset(mix('vendors/js/ckeditor/ckInit.js'))); ?>"></script>

    <?php echo $__env->make('admin.panels.fileManagerScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        var thumbnailIndex = 0;
        var vedioIndex = 0;
        function addThumnails(){
            var clone = `<?php echo $__env->renderWhen(true,'admin.components.workThubmnailClone',['inputIndex' => '`+thumbnailIndex+`'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>`;
            $('#tumbnailCard').append(clone);
            thumbnailIndex++;
        }


        function addVideos(){
            var clone = `<?php echo $__env->renderWhen(true,'admin.components.workVideoClone',['inputIndex' => '`+vedioIndex+`'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>`;
            $('#videoCard').append(clone);
            vedioIndex++;
        }

        
        
        // initialize Packery
        var $grid = $('.grid').packery({
            itemSelector: '.grid-item',
            // columnWidth helps with drop positioning
            columnWidth: 100,
            gutter: 10
        });

        // make all grid-items draggable
        $grid.find('.grid-item').each( function( i, gridItem ) {
            var draggie = new Draggabilly( gridItem );
            // bind drag events to Packery
            $grid.packery( 'bindDraggabillyEvents', draggie );
        });

        // show item order after layout
        function orderItems() {
            var itemElems = $grid.packery('getItemElements');
            $( itemElems ).each( function( i, itemElem ) {
                $( itemElem ).find('span').text( i + 1 );
            });
        }

        $grid.on( 'layoutComplete', orderItems );
        $grid.on( 'dragItemPositioned', orderItems );
        

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/pages/work/create.blade.php ENDPATH**/ ?>