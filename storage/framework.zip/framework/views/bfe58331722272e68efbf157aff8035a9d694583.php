<?php $__env->startSection('pageStyle'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/news.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 relative">
        <?php echo $__env->make('frontend.components.submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<div class="row mt-16">
    <div class="col-lg-12">
        <div class="news-grid">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->renderWhen($item->type == NEWS,'frontend.components.news-page-item', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                <?php echo $__env->renderWhen($item->type != NEWS,'frontend.components.instagram-or-twitter', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/news.blade.php ENDPATH**/ ?>