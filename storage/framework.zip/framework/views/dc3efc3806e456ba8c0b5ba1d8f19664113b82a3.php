<?php $__env->startSection('content'); ?>

<div class="row grid mt-4">
    <div class="grid-sizer col-xs-12 col-sm-12 col-md-6 col-lg-3"></div>

    <div class="row">
        
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 mb-base grid-item">
            <div class="grid-item-content about relative medium">
                <div class="wrap opacity-100 d-flex flex-column  justify-content-center">
                    <div class="header text-left text-xs lg:text-sm">About</div>
                    <div class="line"></div>
                    <div class="content py-5 capitalize text-left font-medium  lg:text-3xl text-xl">
                        <p><strong>Serial Kolor, Inc. is a creative agency. We develop visual concepts and design for digital experiences and creative content.</strong><br /></p>
                    </div>
                    <div class="line low"></div>
                    <div class="footer text-left italic text-xs lg:text-sm">
                        Continue reading
                        <span class="arrow-right">&rarr;</span>
                    </div>
                </div>
        
            </div>
        </div>
        <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($work->type == NEWS): ?>
                <?php echo $__env->renderWhen($works,'frontend.components.news', ['work' => $work,'size' => 3], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php else: ?>
                <?php echo $__env->renderWhen($works,'frontend.components.work', ['work' => $work], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('pageScript'); ?>
    <script src="<?php echo e(asset('vendors/js/packery/packery.pkgd.min.js')); ?>"></script>
    <script src="https://www.jqueryscript.net/demo/Tiny-Equal-Height-Plugin-For-Bootstrap-Grid-System---bootstrap-grid-columns-js/bootstrap-grid-columns.js"></script>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('myScript'); ?>
    <script>
        jQuery(window).on('load', function (e) {
            $('.grid').packery({
                itemSelector: '.grid-item',
                columnWidth: '.grid-sizer',
                percentPosition: true,
                fitWidth: true,
                guttor:0
            });
        });
    </script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('frontend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/index.blade.php ENDPATH**/ ?>