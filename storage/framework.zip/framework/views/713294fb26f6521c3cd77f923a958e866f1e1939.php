<?php $__env->startSection('title', 'Manage Social Links'); ?>


<?php $__env->startSection('vendor-style'); ?>     
<!-- vednor css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/ui/prism.min.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Description -->
<section id="description">
    <div class="row">
        <div class="col-lg-8 offset-lg-2 col-md-12 col-sm-12 ">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('social-links.store')); ?>" method="post" id="mainForm">
                        <?php echo csrf_field(); ?>
                        <div class="col mb-5">
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group multiple-form-group input-group">
                                    <div class="input-group-btn">
                                        <div class="dropdown input-group-select">
                                            <button class="btn btn-primary dropdown-toggle rounded-r-none" type="button" id="dropdownMenuButton"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <span class="concept"><i class="fa <?php echo e($item->icon); ?>"></i> <?php echo e(ucwords(explode('-',$item->icon)[1] ?? '')); ?></span>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item" href="#fa-facebook"><i class="fa fa-facebook"></i>Facebook</a>
                                                <a class="dropdown-item" href="#fa-twitter"><i class="fa fa-twitter"></i>Twitter</a>
                                                <a class="dropdown-item" href="#fa-pinterest"><i class="fa fa-pinterest"></i>Pinterest</a>
                                                <a class="dropdown-item" href="#fa-instagram"><i class="fa fa-instagram"></i>Instagram</a>
                                                <a class="dropdown-item" href="#fa-linkedin"><i class="fa fa-linkedin"></i>Linkedin</a>
                                                <a class="dropdown-item" href="#fa-google-plus"><i class="fa fa-google-plus"></i>Google Plus</a>
                                                <a class="dropdown-item" href="#fa-vimeo"><i class="fa fa-vimeo"></i>Vimeo</a>
                                                <a class="dropdown-item" href="#fa-youtube-play"><i class="fa fa-youtube-play"></i>Youtube</a>
                                            </div>
                                            <input type="hidden" class="input-group-select-val" name="contacts[<?php echo e($key); ?>][icon]" value="<?php echo e($item->icon); ?>">
                                        </div> 
                                    </div>
                                    
                                    <input type="text" name="contacts[<?php echo e($key); ?>][link]" class="form-control link-val" value="<?php echo e($item->link); ?>">
                                    <?php if(count($links->toArray()) !== $key+1): ?>
                                        <span class="input-group-btn">
                                            <button class="btn border-0 btn-danger btn-removed focus:outline-none" type="button"><i class="feather icon-minus"></i></button>
                                        </span>
                                    <?php else: ?>
                                        <span class="input-group-btn">
                                            <button class="btn border-0 btn-primary btn-add focus:outline-none" type="button" data-index="<?php echo e(count($links->toArray())); ?>"><i class="feather icon-plus"></i></button>
                                        </span>
                                    <?php endif; ?>

                                    
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                       

                        <div class="col mt-5 ">
                            <button class="btn  btn-primary float-right" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Description -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/ui/prism.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myscript'); ?>
     <!-- Page js files -->
     <script src="<?php echo e(asset(mix('js/scripts/forms/select/form-select2.js'))); ?>"></script>
     <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/admin/pages/social/index.blade.php ENDPATH**/ ?>