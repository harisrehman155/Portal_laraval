

<?php 

    $url = explode('.',$work->seo_url);
    $goto =  collect($work)->has('seo_url') ? route($url[0].'.detail', $url[1]) : 'javascript:void';
?>

<?php if($work->image): ?>
    <div class="grid-item col-xs-12 col-sm-12 col-md-6 col-lg-<?php echo e($size); ?> mb-base">
        <a href="<?php echo e($goto); ?>">
            <div  class="grid-item-content news overflow-hidden bg-white <?php echo e($work->size); ?>">
                <div class="new-card-image">
                    <img src="<?php echo e(asset($work->image)); ?>" class="img-fluid w-full h-100"/>
                </div>
                <?php if($goto): ?>
                    <div id="item-<?php echo e($work->id); ?>" class="relative bottom-0 py-5 text-center bg-white text-gray-700 transition-all duration-700">
                        <div class="header text-xs lg:text-sm transition-all duration-700 py-0 top-10"><span class="transition-all duration-700">News</span></div>
                        <div class="line transition-all duration-700"></div>
                        <div class="content capitalize text-2xl <?php echo e($size == 4 ? 'md:text-xl' : 'md:text-2xl'); ?>  font-medium px-3">
                            <h3 class="transition-all duration-700"><?php echo $work->title; ?></h3>
                        </div>
                        <div class="line low transition-all duration-700"></div>
                        <div class="footer text-xs lg:text-sm italic transition-all duration-700"><span class="transition-all duration-700">View project</span></div>
                    </div>
                <?php endif; ?>
            </div>
        </a>
    </div>
<?php else: ?>
    <div class="grid-item col-xs-12 col-sm-12 col-md-6 col-lg-<?php echo e($size); ?> mb-base">
        <a href="<?php echo e($goto); ?>">
        <div id="item-<?php echo e($work->id); ?>" class="grid-item-content news relative <?php echo e($work->size); ?>">
            <?php if($goto): ?>
                <div class="wrap  flex flex-col justify-content-center transition-all duration-700">
                    <div class="header text-xs lg:text-sm transition-all duration-700"><span class="transition-all duration-700">News</span></div>
                    <div class="line transition-all duration-700"></div>
                    <div class="content p-3 capitalize text-2xl <?php echo e($size == 4 ? 'md:text-xl' : 'md:text-2xl'); ?>  font-medium">
                        <h3 class="transition-all duration-700"><?php echo $work->title; ?></h3>
                    </div>
                    <div class="line low transition-all duration-700"></div>
                    <div class="footer text-xs lg:text-sm italic transition-all duration-700"><span class="transition-all duration-700">View project</span></div>
                </div>
            <?php endif; ?>
        </div>
        </a>
    </div>
<?php endif; ?>

<?php if($work->bg_color): ?>
<?php $__env->startPush('myStyle'); ?>
    <style>
        #item-<?php echo e($work->id); ?> {
            background: <?php echo e($work->bg_color); ?>!important;
        }

        .grid-item:hover #item-<?php echo e($work->id); ?> {
            background: <?php echo e($work->bg_hover_color); ?>!important;
        }

        .grid-item #item-<?php echo e($work->id); ?> h3,  .grid-item #item-<?php echo e($work->id); ?> .header span, .grid-item #item-<?php echo e($work->id); ?> .footer span {
            color: <?php echo e($work->anchor_color); ?>!important;
        }

        .grid-item #item-<?php echo e($work->id); ?> .arrow-right {
            color: <?php echo e($work->line_color); ?>!important;
        }

        .grid-item:hover #item-<?php echo e($work->id); ?> h3, .grid-item:hover #item-<?php echo e($work->id); ?> .header span, .grid-item:hover #item-<?php echo e($work->id); ?> .footer span {
            color: <?php echo e($work->anchor_hover_color); ?>!important;
        }

        .grid-item #item-<?php echo e($work->id); ?> .line {
            background: <?php echo e($work->line_color); ?>!important;
        }
        .grid-item:hover #item-<?php echo e($work->id); ?> .line , .grid-item:hover #item-<?php echo e($work->id); ?> .arrow-right {
            background: <?php echo e($work->line_hover_color); ?>!important;                        
        }
    </style>
<?php $__env->stopPush(); ?>

<?php endif; ?><?php /**PATH H:\xampp\htdocs\serialkolor\vueexy\resources\views/frontend/components/news.blade.php ENDPATH**/ ?>