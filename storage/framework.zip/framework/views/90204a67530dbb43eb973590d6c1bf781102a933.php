<?php $__env->startComponent('mail::message'); ?>

# ORDER ID 0<?php echo e($order->id); ?>


---------------------------------

**Email:** <?php echo e($user->email); ?><br>
**Cell:** <?php echo e($user->cell_number); ?><br>
**Phone:** <?php echo e($user->phone_number); ?><br>

**Date:** <?php echo e(date('y-d-m', strtotime($order->created_at))); ?>


-----------------------------------------------------------------------

# Order Detail

**Instructions:** <?php echo e($order->instructions); ?> <br>

**Design Name:**  <?php echo e($order->design_name); ?> <br>
**PO#:**  <?php echo e($order->po_no); ?> <br>
**Number Of Colors:**  <?php echo e($order->number_of_colors); ?> <br>
**Color Type:**  <?php echo e($order->color_type); ?> <br>
**Required Format:**  <?php echo e($order->required_format); ?> <br>
**Super Urgent:**  <?php echo e($order->is_urgent ? 'Yes' : 'No'); ?> <br>

<?php $__env->startComponent('mail::button', ['url' => $filesUrl]); ?>
    Download Files
<?php echo $__env->renderComponent(); ?>

-----------------------------------------------------------------------


Thanks,<br>
<?php echo e(str_replace('-' , ' ', config('app.name'))); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/termzewy/portal.terminatorpunch.com/resources/views/email/vectorOrderMail.blade.php ENDPATH**/ ?>