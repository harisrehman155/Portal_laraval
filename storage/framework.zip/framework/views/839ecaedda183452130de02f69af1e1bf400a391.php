
<?php $__env->startSection('title', 'Manage Order'); ?>
<?php $__env->startSection('vendor-style'); ?>
        <!-- vednor css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/ui/prism.min.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/file-uploaders/dropzone.min.css'))); ?>">
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/forms/select/select2.min.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mystyle'); ?>
        <!-- Page css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/file-uploaders/dropzone.css'))); ?>">
        <style>
            i.feather.icon-x-circle {
                font-size: 18px;
                color: red;
            }
            i.feather.icon-check-circle {
                font-size: 18px;
                color: green;
            }
        </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section id="vector">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body card-dashboard pt-3">
                            <form method="POST" action="<?php echo e(route('complete.order')); ?>">
                                <?php echo csrf_field(); ?>
                                
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-12 mt-2">
                                        <div class="form-label-group">
                                            <select name="order_id" id="order_id" class="select2-icons form-control <?php $__errorArgs = ['order_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="" disabled selected>Select Order</option>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option data-icon="feather icon-<?php echo e($item->status ? 'check-circle' : 'x-circle'); ?>" value="<?php echo e($item->id); ?>">0<?php echo e($item->id .'-'. $item->design_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            </select>
                                            <label for="order_id">Color Type</label>
                                            <?php $__errorArgs = ['order_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="document">Files To Upload</label>
                                            <div class="needsclick dropzone" id="document-dropzone">
                                                <div class="dz-message">Drop Files Here To Upload</div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        
                                    </div>
                                </div>
                                <button type="submit" id="submitBtn" class="btn btn-primary float-right btn-inline mb-3">Place Order</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- Dashboard Analytics end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
        <!-- vednor files -->
        <script src="<?php echo e(asset(mix('vendors/js/extensions/dropzone.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/forms/select/select2.full.min.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/ui/prism.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myscript'); ?>

<script src="<?php echo e(asset(mix('js/scripts/forms/select/form-select2.js'))); ?>"></script>
<script>
    var uploadedDocumentMap = {}
    Dropzone.options.documentDropzone = {
      url: '<?php echo e(route('customer.storeMedia')); ?>',
      maxFilesize: 300, // MB
      addRemoveLinks: true,
      headers: {
        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
      },
      totaluploadprogress: function(progress){
        if(progress == 100){
            $('#submitBtn').removeAttr('disabled');
            $('#submitBtn').html('');
            $('#submitBtn').html('Place Order');
        }else if(progress < 100){
            var html = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
            if($('#submitBtn').html() != html){
                $('#submitBtn').attr('disabled', 'true');
                $('#submitBtn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...');
            }
        }
      },
      success: function (file, response) {
        $('form').append('<input type="hidden" name="document[]" value="' + response.name + '">')
        uploadedDocumentMap[file.name] = response.name
      },
      removedfile: function (file) {
        file.previewElement.remove()
        var name = ''
        if (typeof file.file_name !== 'undefined') {
          name = file.file_name
        } else {
          name = uploadedDocumentMap[file.name]
        }
        $('form').find('input[name="document[]"][value="' + name + '"]').remove()
      },
      init: function () {
        <?php if(isset($order) && $order->getMedia('document')): ?>
          var files =
            <?php echo json_encode($order->getMedia('document')); ?>

          for (var i in files) {
            var file = files[i]
            this.options.addedfile.call(this, file)
            file.previewElement.classList.add('dz-complete')
            // console.log(file.file_name);
            $('form').append(`<input type="hidden" name="document[]" value="${file.file_name}">`)
          }
        <?php endif; ?>
      }
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('portal/layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/termzewy/portal.terminatorpunch.com/resources/views/portal/pages/ordersManagement.blade.php ENDPATH**/ ?>